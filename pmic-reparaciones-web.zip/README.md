# ⚡ PMIC Reparaciones - Sitio Web Oficial

Sitio web profesional, interactivo y de alta gama para **PMIC Reparaciones**, taller de microelectrónica y reparación de celulares, notebooks y consolas en **Santa Rosa, La Pampa**.

---

## 🚀 Características Principales

1. **Diseño Dark Mode Tecno de Alto Nivel:**
   - Paleta de colores oficial: Fondos carbón obsidiana, naranja neón circuito (`#ff6a00`), cian eléctrico y degradados metálicos cromados.
   - Logo oficial y chip electrónico con pistas de circuito impreso (PCB) animadas mediante HTML5 Canvas.
   - Tipografías modernas: *Orbitron* (tecnológica / branding), *Rajdhani* (subtítulos y números) e *Inter* (lectura óptima).
   - Efecto 3D de inclinación (*tilt*) interactivo en tarjeta de laboratorio.

2. **Cotizador Interactivo a WhatsApp:**
   - Selector intuitivo de dispositivo (**Android**, **iPhone**, **Notebook/PC**, **PlayStation/Consolas**).
   - Sugerencias rápidas de modelos (Samsung S24, Moto Edge, iPhone 15, PS5, etc.).
   - Selección de falla (pantalla, batería, pin de carga, no enciende, mojado, mantenimiento térmico, HDMI, drift de joystick).
   - Selector de urgencia (Estándar o Urgente Express en el día).
   - **Ticket Digital en tiempo real:** Muestra una vista previa de terminal con los datos y genera con un solo clic el enlace directo a WhatsApp (`+54 9 2954 27-4960`) con formato claro y emojis.
   - Opción para copiar los datos al portapapeles.

3. **Botón Flotante de WhatsApp con Efecto Radar:**
   - Botón pulsante con ondas de radar continuas en la esquina inferior derecha.
   - Badge de notificación activa.
   - Diálogo emergente interactivo para iniciar chat rápido con soporte técnico.

4. **Medios de Pago Integrados:**
   - Réplica exacta de los medios de pago del flyer: VISA, MasterCard, American Express, Tarjeta Naranja, Mercado Pago y Transferencia Bancaria.

5. **Garantía Legal de 30 Días (Ley 24.240):**
   - Cobertura estricta según la Ley 24.240 de Defensa del Consumidor, contados desde la fecha de aviso de reparado.
   - Términos legales claros sobre exclusiones (golpes, sobretensión, humedad, software y equipos previamente mojados), talón obligatorio de Orden de Reparación© y plazo de revisión de 48 hs.

6. **100% Responsive & Mobile-First:**
   - Menú hamburguesa deslizable con efecto desenfoque *glassmorphism*.
   - Adaptado a cualquier pantalla: celulares, tablets, laptops y pantallas 4K.

7. **Localización & Contacto:**
   - Dirección oficial: **Santa Rosa, La Pampa** (Coordenadas exactas: `[-36.64026860665512, -64.290792]`).
   - Mapa interactivo de Google Maps integrado en modo nocturno con pin centrado directamente en la puerta del taller.
   - Horarios de laboratorio: **Lunes a Viernes: 09:00 - 17:00 hs** | **Sábados: 10:00 - 16:00 hs**.
   - Enlaces directos de llamada y chat a WhatsApp (`2954274960`).

---

## 📂 Estructura de Archivos

```
pmic-reparaciones/
├── index.html                 # Página principal
├── css/
│   └── styles.css             # Hoja de estilos Cyber Dark Mode
├── js/
│   └── app.js                 # Lógica interactiva (cotizador, canvas, modales)
├── assets/
│   ├── pmic-banner.jpg        # Flyer original oficial
│   ├── chip-logo-clean.png    # Chip con pistas de cobre y logo R
│   ├── pmic-brand-clean.png   # Tipografía cromada PMIC REPARACIONES
│   └── payment-methods.png    # Faja de medios de pago oficial
└── README.md                  # Documentación
```

---

## 💻 Cómo Abrir el Sitio

No requiere instalar ningún programa ni servidor:
- Hacé doble clic en `index.html` para abrirlo directamente en cualquier navegador (Google Chrome, Microsoft Edge, Brave, Firefox, etc.).
- O subí la carpeta a cualquier servicio de hosting gratuito (Netlify, Vercel, GitHub Pages) para tenerlo online con dominio propio.
